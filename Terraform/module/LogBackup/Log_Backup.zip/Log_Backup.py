import boto3
import os
from pprint import pprint
import time

logs = boto3.client('logs')

def handler(event, context):
    log_groups = []
    log_groups_to_export = []
    
    if 'S3_BUCKET' not in os.environ:
        print("Error: S3_BUCKET not defined")
        return

    while True:
        # 로그 그룹 데이터만 파싱
        response = logs.describe_log_groups()
        print(response)
        log_groups = log_groups + response['logGroups']
        
        if not 'nextToken' in response:
            break
    
    # 로그 그룹명만 파싱
    for log_group in log_groups:
        log_groups_to_export.append(log_group['logGroupName'])
    
    # 각 로그 그룹에 대하여 백업
    for log_group_name in log_groups_to_export:
        response = logs.create_export_task(
            logGroupName=log_group_name,
            # 지난 N시간동안의 로그 백업
            fromTime = int(time.time() * 1000 - int(os.environ['HOURS']) * 3600000),
            to       = int(time.time() * 1000),
            destination=os.environ['S3_BUCKET'],
            destinationPrefix=log_group_name.strip("/")
        )
        
        # create_export_task는 한번에 하나만 RUNNING 혹은 PENDING 상태여야함
        # 현재 작업이 끝나야 다음 작업으로 넘어가게 함
        taskId = (response['taskId'])
        status = 'RUNNING'
        while status in ['RUNNING','PENDING']:
            response_desc = logs.describe_export_tasks(
                taskId=taskId
            )
            status = response_desc['exportTasks'][0]['status']['code']
            # 과도한 리소스 사용 제한
            time.sleep(3)