create table cloud_db.Thumbnail (
NUM int unsigned not null auto_increment,
FILE_UPLOAD varchar(10) NOT NULL,
FILE_SEQ char(6),
FILE_NAME varchar(100),
FILE_TEXT varchar(255),
FILE_ADMIN varchar(50),
FILE_GROUP char(2) NOT NULL,
REGIST_DAY varchar(30),
primary key(NUM, FILE_SEQ)
)charset = utf8;
