create table cloud_db.Video (
NUM int unsigned not null auto_increment,
VIDEO_SEQ varchar(10) NOT NULL,
VIDEO_GROUP char(2),
VIDEO_NAME varchar(30),
VIDEO_SUBJECT varchar(100),
VIDEO_FILE varchar(32) NOT NULL,
VIDEO_ADMIN varchar(50),
REGIST_DAY varchar(30),
primary key(NUM, VIDEO_SEQ)
)charset = utf8;

