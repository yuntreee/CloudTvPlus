create database cloud_db;
create user cloudadmin identified by 'cloud';
grant all on cloud_db.* to cloudadmin@'localhost' identified by 'cloud';
grant all on cloud_db.* to cloudadmin@'%' identified by 'cloud';
grant all privileges on cloud_db.* to 'cloudadmin'@'localhost' identified by 'cloud';
grant all privileges on cloud_db.* to 'cloudadmin'@'%' identified by 'cloud';
flush privileges;


참고 
create database care_db;
create user careadmin identified by 'hackers';
grant all on care_db.* to careadmin@'localhost' identified by 'hackers';
grant all on care_db.* to careadmin@'%' identified by 'hackers';
grant all privileges on care_db.* to 'careadmin'@'localhost' identified by 'hackers';
grant all privileges on care_db.* to 'careadmin'@'%' identified by 'hackers';
flush privileges;

